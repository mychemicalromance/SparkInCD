import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.nio.channels.FileLock;
import java.nio.file.FileAlreadyExistsException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.compress.archivers.zip.ZipArchiveEntry;
import org.apache.commons.compress.archivers.zip.ZipArchiveInputStream;
import org.apache.commons.io.IOUtils;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPFile;
import org.apache.commons.net.ftp.FTPReply;

import com.alibaba.fastjson.JSON;

public class DownloadAndUnzip {
	public static int BUFFER_SIZE = 2048;
	public static void main(String[] args) {
		String ftpServer = args[0];
		int port = Integer.parseInt(args[1]);
		String username = args[2];
		String password = args[3];
		String path = args[4];
		String zipFile = args[5];
		//下载到哪里，注意，这里是绝对路径，配置项remote_spark_submit_workdir+/+sparkId
		String parentPath = args[6];
		String md5 = args[7];
		if(!parentPath.endsWith(File.separator)){
			parentPath = parentPath+File.separator;
		}
		Path p = Paths.get(parentPath);
		try {
			if(!Files.exists(p)){
				Files.createDirectory(p);
			}
		} catch (FileAlreadyExistsException e1) {
			
		} catch (IOException e2){
			System.out.println("error:create directory");
			return;
		}
		Path fileLock = Paths.get(parentPath, "lock");
		try {
			if(!Files.exists(fileLock)){
				Files.createFile(fileLock);
			}
		} catch (FileAlreadyExistsException e1) {
			
		} catch (IOException e1) {
			System.out.println("error:create lock file");
			return;
		}
		File lock = new File(parentPath+"lock");
		FileLock check = null;
		RandomAccessFile raf = null;
		try {
			raf = new RandomAccessFile(lock, "rw");
			check = raf.getChannel().lock();
		} catch (IOException e1) {
			System.out.println("error:lock file not exist");
			return;
		}
		try{
			//首先检查是否存在已经下载解压的包，如果存在，比较md5值，如果值相等，直接读取并返回，如果不相等，清空目录下载解压
			File f = new File(parentPath+"md5");
			if(f.exists()){
				byte[] bs = new byte[1024];
				try(FileInputStream input = new FileInputStream(f)){
					int len = input.read(bs);
					String existMd5 = new String(bs,0,len);
					if(md5.equals(existMd5)){
						System.out.println(getResult(parentPath));
						return;
					}
				}catch(Exception e){
					
				}
			}
			boolean b = downloadFile(ftpServer, port, username, password, path, zipFile, parentPath);
			if (b) {
				File zip = new File(parentPath + zipFile);
				try {
					unZip(zip, null);
					File md5file = new File(parentPath+"md5");
					if(md5file.exists()){
						md5file.delete();
					}
					//将md5值写入md5文件中
					md5file.createNewFile();
					try(FileWriter fw = new FileWriter(md5file)){
						fw.write(md5);
					}
					System.out.println(getResult(parentPath));
					return;
				} catch (Exception e) {
					System.out.println("error:unzip");
				}
			}
		}finally{
			if(check.isValid()){
				try {
					check.release();
				} catch (IOException e) {
					
				}
			}
			if(raf!=null){
				try {
					raf.close();
				} catch (IOException e) {
					
				}
			}
		}
		System.out.println("error:end");
	}
	
	public static String getResult(String parentPath){
		// 解压完成后，返回lib下所有jar包，还有bin下的jar
		File libDir = new File(parentPath + "lib");
		File binDir = new File(parentPath + "bin");
		FilenameFilter ff = new FilenameFilter() {
			@Override
			public boolean accept(File dir, String name) {
				return name.endsWith(".jar");
			}
		};
		File[] libjars = libDir.listFiles(ff);
		File[] binjars = binDir.listFiles(ff);
		Map<String,List<String>> result = new HashMap<>();
		List<String> lib = new ArrayList<>();
		for(File f:libjars){
			lib.add(f.getAbsolutePath());
		}
		List<String> bin = new ArrayList<>();
		for(File f:binjars){
			bin.add(f.getAbsolutePath());
		}
		result.put("lib", lib);
		result.put("bin", bin);
		return JSON.toJSONString(result);
	}

	public static boolean downloadFile(String url, int port, String username, String password, String path,
			String filename, String downloadParentPath) {
		boolean success = false;
		if (!downloadParentPath.endsWith(File.separator))
			downloadParentPath = downloadParentPath + File.separator;
		File dir = new File(downloadParentPath);
		if (!dir.exists()) {
			dir.mkdirs();
		}
		FTPClient ftp = new FTPClient();
		try {
			int reply;
			ftp.connect(url, port);// 连接FTP服务器
			// 如果采用默认端口，可以使用ftp.connect(url)的方式直接连接FTP服务器
			ftp.login(username, password);// 登录
			reply = ftp.getReplyCode();
			if (!FTPReply.isPositiveCompletion(reply)) {
				ftp.disconnect();
				return success;
			}
			ftp.enterLocalPassiveMode();
			ftp.setFileType(FTPClient.BINARY_FILE_TYPE);
			ftp.changeWorkingDirectory(path);

			FTPFile[] ftpFiles = ftp.listFiles();
			for (FTPFile ftpFile : ftpFiles) {
				if (ftpFile.getName().equals(filename)) {
					File f = new File(downloadParentPath + ftpFile.getName());
					if (f.exists())
						f.delete();
					f.createNewFile();
					OutputStream local = new FileOutputStream(f);
					InputStream input = ftp.retrieveFileStream(ftpFile.getName());
					byte[] b = new byte[1024 * 1000];
					int length = 0;
					while ((length = input.read(b)) != -1) {
						local.write(b, 0, length);
					}
					local.flush();
					local.close();
					input.close();
				}
			}
			ftp.logout();
			success = true;
		} catch (IOException e) {
			System.out.println("error:download");
		} finally {
			if (ftp.isConnected()) {
				try {
					ftp.disconnect();
				} catch (IOException ioe) {
					System.out.println("error:download");
				}
			}
		}
		return success;
	}

	public static List<String> unZip(File zipfile, String destDir) throws Exception {
		if (destDir == null || destDir.equals("")) {
			destDir = zipfile.getParent();
		}
		destDir = destDir.endsWith(File.separator) ? destDir : destDir + File.separator;
		File targetDir = new File(destDir);
		if (!targetDir.exists()) {
			targetDir.mkdirs();
		}
		ZipArchiveInputStream is = null;
		List<String> fileNames = new ArrayList<String>();

		try {
			is = new ZipArchiveInputStream(new BufferedInputStream(new FileInputStream(zipfile), BUFFER_SIZE));
			ZipArchiveEntry entry = null;
			while ((entry = is.getNextZipEntry()) != null) {
				fileNames.add(entry.getName());
				if (entry.isDirectory()) {
					File directory = new File(destDir, entry.getName());
					if (directory.exists()) {
						directory.delete();
					}
					directory.mkdirs();
				} else {
					File file = new File(destDir, entry.getName());
					if (file.exists()) {
						file.delete();
					}
					OutputStream os = null;
					try {
						os = new BufferedOutputStream(new FileOutputStream(file), BUFFER_SIZE);
						IOUtils.copy(is, os);
					} finally {
						IOUtils.closeQuietly(os);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			IOUtils.closeQuietly(is);
		}
		return fileNames;
	}
}
